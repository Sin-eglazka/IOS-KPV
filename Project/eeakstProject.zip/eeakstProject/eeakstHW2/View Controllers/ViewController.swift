//
//  ViewController.swift
//  eeakstHW2
//
//  Created by Kate on 21.09.2022.
//

import UIKit
import SwiftUI

protocol GetTableStudents : class {
    func update(table: [String])
}

class ViewController: UIViewController, GetTableStudents {

    private let mainLabel = UILabel()
    
    private var commentView = UIView()
    
    let controllerGroup: GroupViewController = GroupViewController()
    
    let timerController = TimerViewController()
    
    let breakGroupsViewController = BreakGroupsViewController()
    
    private var listOfStudents: [String] = []
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        setupView()
    }
    
    func assignBackground(){
        let background = UIImage(named: "mainBackground")
        var imageView : UIImageView!
        imageView = UIImageView(frame: view.bounds)
        imageView.contentMode = UIView.ContentMode.scaleAspectFill
        imageView.clipsToBounds = true
        imageView.image = background
        imageView.center = view.center
        view.addSubview(imageView)
        self.view.sendSubviewToBack(imageView)
        }
    
    private func setupCommentView() -> UIView {
         let commentView = UIView()
         commentView.backgroundColor = .white
         commentView.layer.cornerRadius = 0
         view.addSubview(commentView)
         commentView.pinTop(to:
         self.view.topAnchor)
         commentView.pin(to: self.view, [.left: 0, .right: 0])
         mainLabel.font = .systemFont(ofSize: 25, weight: .regular)
         mainLabel.textColor = .black
         mainLabel.numberOfLines = 0
         mainLabel.textAlignment = .center
        mainLabel.text = "Main Menu"
         commentView.addSubview(mainLabel)
         mainLabel.pin(to: commentView, [.top: 30, .left: 16, .bottom: 30, .right: 16])
         return commentView
     }
    
    private func setupView() {
        
        assignBackground()
        commentView = setupCommentView()
        setupMenuButtons()
        self.navigationController?.navigationBar.barStyle = .black
        self.navigationController?.navigationBar.tintColor = .black
     }
    
    
    private func makeMenuButton(title: String) -> UIButton {
         let button = UIButton()
         button.setTitle(title, for: .normal)
         button.setTitleColor(.black, for: .normal)
         button.layer.cornerRadius = 12
         button.titleLabel?.font = .systemFont(ofSize: 25, weight: .medium)
         button.backgroundColor = .white
         button.heightAnchor.constraint(equalTo: button.widthAnchor).isActive = true
         return button
     }
    
    private func setupMenuButtons() {
         let createGroupButton = makeMenuButton(title: "Change Group")
         createGroupButton.addTarget(self, action:
            #selector(changeGroupButtonPressed), for:.touchUpInside)
         
        let timerButton = makeMenuButton(title: "Set Timer")
        timerButton.addTarget(self, action: #selector(timerButtonPressed), for:.touchUpInside)
        
        let chooseStudentButton = makeMenuButton(title: "Choose Student")
        chooseStudentButton.addTarget(self, action: #selector(chooseStudentButtonPressed), for: .touchUpInside)
        
        let groupStudentsButton = makeMenuButton(title: "Group Students")
        groupStudentsButton.addTarget(self, action: #selector(groupButtonPressed), for: .touchUpInside)
        
        let topButtons = UIStackView(arrangedSubviews: [chooseStudentButton, timerButton])
        topButtons.axis = .horizontal
        topButtons.spacing = 20
        topButtons.distribution = .fillEqually
         let bottomButtons = UIStackView(arrangedSubviews: [createGroupButton, groupStudentsButton])
        bottomButtons.axis = .horizontal
        bottomButtons.spacing = 20
        bottomButtons.distribution = .fillEqually
        let allButtons = UIStackView(arrangedSubviews: [topButtons, bottomButtons])
        allButtons.spacing = 35	
        allButtons.axis = .vertical
         self.view.addSubview(allButtons)
        allButtons.pin(to: self.view, [.left: 24, .right: 24])
        allButtons.pinTop(to:
         self.view.safeAreaLayoutGuide.topAnchor, 150)
         
     }
    
    @objc
    private func chooseStudentButtonPressed() {
        let popUpStudent = PopUpStudentController()
        self.addChild(popUpStudent)
        popUpStudent.view.frame = self.view.frame
        popUpStudent.setStudentName(name: listOfStudents.randomElement() ?? "No Students in group")
        self.view.addSubview(popUpStudent.view)
        popUpStudent.didMove(toParent: self)
    }	
    
    @objc
    private func timerButtonPressed() {
        navigationController?.pushViewController(timerController, animated: true)
    }
    
    @objc
    private func changeGroupButtonPressed() {
        controllerGroup.delegate = self
        self.navigationController?.pushViewController(controllerGroup, animated: true)
        let generator = UIImpactFeedbackGenerator(style: .medium)
        generator.impactOccurred()
    }
    
    @objc
    private func groupButtonPressed() {
        breakGroupsViewController.updateStudentList(listStudents: listOfStudents)
        navigationController?.pushViewController(breakGroupsViewController, animated: true)
    }
    
    func update(table: [String]){
        listOfStudents = table
        breakGroupsViewController.updateStudentList(listStudents: listOfStudents)
    }
    
}

	
