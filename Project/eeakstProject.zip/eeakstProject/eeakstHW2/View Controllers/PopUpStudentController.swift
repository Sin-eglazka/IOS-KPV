
import UIKit
 
class PopUpStudentController: UIViewController {
 
    let closeButton: UIButton = UIButton()
    let studentLabel = UILabel()
     
    override func viewDidLoad() {
        super.viewDidLoad()
        self.view.backgroundColor = UIColor.black.withAlphaComponent(0.75)
        setUpViews()
        moveIn()
   }
    
    @objc
    func closePopUp(_ sender: UIButton) {
        moveOut()
    }
    
    func setUpViews(){
    
        studentLabel.font = .systemFont(ofSize: 45, weight: .regular)
        studentLabel.textColor = .black
        studentLabel.numberOfLines = 0
        studentLabel.textAlignment = .center
        
        let closeButtonRight = UIButton(type: .close)
        closeButtonRight.addTarget(self, action: #selector(closePopUp), for: .touchUpInside)
        let viewButton = UIView()
        viewButton.addSubview(closeButtonRight)
        viewButton.setHeight(to: 30)
        closeButtonRight.pin(to: viewButton, [.right:5, .top:3])
        
        closeButton.setTitle("Close", for: .normal)
        closeButton.titleLabel?.font = .systemFont(ofSize: 25, weight: .regular)
        closeButton.addTarget(self, action:
           #selector(closePopUp), for:.touchUpInside)
        
        let studentView = UIStackView(arrangedSubviews: [viewButton, studentLabel, closeButton])
        self.view.addSubview(studentView)
        studentView.spacing = 35
        studentView.axis = .vertical
        studentView.backgroundColor = UIColor(red: 1.00, green: 0.75, blue: 0.63, alpha: 1.00)
        studentView.layer.cornerRadius = 20
        studentView.pinTop(to:
        self.view.centerYAnchor)
        studentView.pin(to: self.view, [.left: 30, .right: 30, .bottom: self.view.frame.size.height / 3, .top: self.view.frame.size.height / 3])
        
        
        
    }
    
    func setStudentName(name: String){
        studentLabel.text = name
    }
     
    func moveIn() {
        self.view.transform = CGAffineTransform(scaleX: 1.35, y: 1.35)
        self.view.alpha = 0.0
         
        UIView.animate(withDuration: 0.24) {
            self.view.transform = CGAffineTransform(scaleX: 1.0, y: 1.0)
            self.view.alpha = 1.0
        }
    }
     
    func moveOut() {
        UIView.animate(withDuration: 0.24, animations: {
            self.view.transform = CGAffineTransform(scaleX: 1.35, y: 1.35)
            self.view.alpha = 0.0
        }) { _ in
            self.view.removeFromSuperview()
        }
    }
}
