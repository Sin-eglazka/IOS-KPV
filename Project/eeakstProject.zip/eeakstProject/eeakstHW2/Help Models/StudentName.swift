//
//  ShortNote.swift
//  eeakstHW3
//
//  Created by Kate on 10.10.2022.
//

import Foundation

struct StudentName {
 var text: String
}
